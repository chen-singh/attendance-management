package ams.Service;

import ams.Service.StudentService;
import ams.model.Student;
import ams.Util.*;

import java.time.LocalDate;
import java.util.*;

public class AttendanceService {
    private final String FILE_PATH = "data/attendance.csv";
    private final List<String[]> records = new ArrayList<>();

    public void load() {
        records.clear();
        records.addAll(CsvUtil.readLines(FILE_PATH));
    }

    public void save() {
        CsvUtil.writeLines(FILE_PATH, records);
    }

    public void markAttendance(int studentId) {
        String today = LocalDate.now().toString();
        for (String[] r : records) {
            if (r[0].equals(today) && Integer.parseInt(r[1]) == studentId) {
                System.out.println("Already marked."); return;
            }
        }
        records.add(new String[]{today, studentId + "", "P"});
        System.out.println("Marked Present.");
    }

    public void viewStudentHistory(int studentId) {
        for (String[] r : records) {
            if (Integer.parseInt(r[1]) == studentId) {
                System.out.println(r[0] + " - " + r[2]);
            }
        }
    }

    public void takeClassAttendance() {
        Scanner sc = new Scanner(System.in);
        String today = LocalDate.now().toString();
        for (Student s : StudentService.students) {
            System.out.print("Mark attendance for " + s.getName() + " (P/A): ");
            String status = sc.nextLine().trim().toUpperCase();
            if (!status.equals("P")) status = "A";
            records.add(new String[]{today, s.getId() + "", status});
        }
    }

    public void viewClassReport() {
        Map<Integer, List<String>> map = new HashMap<>();
        for (String[] r : records) {
            int id = Integer.parseInt(r[1]);
            map.putIfAbsent(id, new ArrayList<>());
            map.get(id).add(r[2]);
        }
        for (Student s : StudentService.students) {
            List<String> stat = map.getOrDefault(s.getId(), new ArrayList<>());
            long p = stat.stream().filter(x -> x.equals("P")).count();
            long a = stat.stream().filter(x -> x.equals("A")).count();
            System.out.println(s.getName() + " - Present: " + p + ", Absent: " + a);
        }
    }
}
