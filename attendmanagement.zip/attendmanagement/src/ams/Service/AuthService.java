package ams.Service;

import ams.model.*;
import ams.Util.*;

import java.util.*;

public class AuthService {
    public Student studentLogin(String name, String password) {
        for (Student s : StudentService.students) {
            if (s.getName().equals(name) && s.checkPassword(password)) return s;
        }
        return null;
    }

    public Teacher teacherLogin(String name, String password) {
        // Hardcoded for simplicity
        if (name.equals("teacher") && password.equals("admin")) {
            return new Teacher(0, "teacher", AuthUtil.sha256("admin"));
        }
        return null;
    }
}