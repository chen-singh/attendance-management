package ams.Service;


import ams.model.*;
import ams.Util.*;

import java.util.*;
import java.io.*;

public class StudentService {
    public static List<Student> students = new ArrayList<>();
    private final String FILE_PATH = "data/students.csv";

    public void load() {
        students.clear();
        List<String[]> lines = CsvUtil.readLines(FILE_PATH);
        for (String[] line : lines) {
            students.add(new Student(Integer.parseInt(line[0]), line[1], line[2]));
        }
    }

    public void save() {
        List<String[]> lines = new ArrayList<>();
        for (Student s : students) {
            lines.add(new String[]{s.getId()+"", s.getName(), s.getPasswordHash()});
        }
        CsvUtil.writeLines(FILE_PATH, lines);
    }

    public void addStudent() {
        Scanner sc = new Scanner(System.in);
        System.out.print("ID: "); int id = Integer.parseInt(sc.nextLine());
        System.out.print("Name: "); String name = sc.nextLine();
        System.out.print("Password: "); String pass = sc.nextLine();
        students.add(new Student(id, name, AuthUtil.sha256(pass)));
        System.out.println("Student added.");
    }

    public void deleteStudent() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter ID to delete: "); int id = Integer.parseInt(sc.nextLine());
        students.removeIf(s -> s.getId() == id);
        System.out.println("Deleted.");
    }

    public void editStudent() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter ID to edit: "); int id = Integer.parseInt(sc.nextLine());
        for (Student s : students) {
            if (s.getId() == id) {
                System.out.print("New Name: "); s.name = sc.nextLine();
                System.out.print("New Password: "); s.passwordHash = AuthUtil.sha256(sc.nextLine());
                System.out.println("Updated.");
                return;
            }
        }
        System.out.println("Student not found.");
    }
}