package ams.model;



public class Student extends User {
    public Student(int id, String name, String passwordHash) {
        super(id, name, passwordHash);
    }


}