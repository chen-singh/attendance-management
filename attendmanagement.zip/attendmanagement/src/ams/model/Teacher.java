package ams.model;

public class Teacher extends User {
    public Teacher(int id, String name, String passwordHash) {
        super(id, name, passwordHash);
    }
}