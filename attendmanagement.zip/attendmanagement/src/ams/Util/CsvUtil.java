package ams.Util;

import java.io.*;
import java.util.*;

public class CsvUtil {
    public static List<String[]> readLines(String filePath) {
        List<String[]> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
        } catch (IOException e) {
            // Ignore if file doesn't exist
        }
        return lines;
    }

    public static void writeLines(String filePath, List<String[]> lines) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filePath))) {
            for (String[] line : lines) {
                pw.println(String.join(",", line));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
