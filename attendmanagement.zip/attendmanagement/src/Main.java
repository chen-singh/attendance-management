/*
import model.*;
import service.*;
import util.*;

import java.util.*;
import java.time.LocalDate;
import java.io.File;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static StudentService studentService = new StudentService();
    static AttendanceService attendanceService = new AttendanceService();
    static AuthService authService = new AuthService();

    public static void main(String[] args) {
        new File("data").mkdir();
        studentService.load();
        attendanceService.load();

        while (true) {
            System.out.println("=============================");
            System.out.println(" ATTENDANCE  MANAGEMENT  CLI");
            System.out.println("=============================");
            System.out.println("1) Student Login");
            System.out.println("2) Teacher Login");
            System.out.println("3) Exit");
            System.out.print("> ");

            String choice = sc.nextLine();
            switch (choice) {
                case "1": studentMenu(); break;
                case "2": teacherMenu(); break;
                case "3": studentService.save(); attendanceService.save(); System.exit(0);
                default: System.out.println("Invalid option");
            }
        }
    }

    static void studentMenu() {
        System.out.print("Enter name: "); String name = sc.nextLine();
        System.out.print("Enter password: "); String pass = sc.nextLine();
        Student student = authService.studentLogin(name, pass);
        if (student == null) { System.out.println("Login failed"); return; }
        while (true) {
            System.out.println("1) Mark Attendance");
            System.out.println("2) View History");
            System.out.println("3) Logout");
            System.out.print("> ");
            String ch = sc.nextLine();
            if (ch.equals("1")) attendanceService.markAttendance(student.getId());
            else if (ch.equals("2")) attendanceService.viewStudentHistory(student.getId());
            else if (ch.equals("3")) return;
            else System.out.println("Invalid");
        }
    }

    static void teacherMenu() {
        System.out.print("Enter name: "); String name = sc.nextLine();
        System.out.print("Enter password: "); String pass = sc.nextLine();
        Teacher teacher = authService.teacherLogin(name, pass);
        if (teacher == null) { System.out.println("Login failed"); return; }
        while (true) {
            System.out.println("1) Add Student");
            System.out.println("2) Delete Student");
            System.out.println("3) Edit Student");
            System.out.println("4) Take Attendance");
            System.out.println("5) View Report");
            System.out.println("6) Logout");
            System.out.print("> ");
            String ch = sc.nextLine();
            switch (ch) {
                case "1": studentService.addStudent(); break;
                case "2": studentService.deleteStudent(); break;
                case "3": studentService.editStudent(); break;
                case "4": attendanceService.takeClassAttendance(); break;
                case "5": attendanceService.viewClassReport(); break;
                case "6": return;
                default: System.out.println("Invalid");
            }
        }
    }
}
*/
